package com.smartfarm.www;

import android.content.Context;

import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;

public class AwsConnector {

    // S3 SDK에 들어있는 클래스 (AWS의 s3을 사용하기 위한 클래스)
    private static TransferUtility transferUtility;

    private AwsConnector(){

    }

    public static TransferUtility getInitializeAwsS3(Context context) {
        if(transferUtility==null){

            // AWS 자격인증을 얻는 코드
            // Cognito를 이용하면 개발자 인증서를 앱에 직접 심지 않아도 되어 apk가 털려서 인증서가 유출 될 위험이 없다.
            // 개발자 인증 자격 증명을 사용하면 를 사용하여 사용자 데이터를 동기화하고 AWS 리소스에 액세스하면서도
            // 자신의 기존 인증 프로세스를 통해 사용자를 등록 및 인증할 수 있다.
            CognitoCachingCredentialsProvider credentialsProvider = new CognitoCachingCredentialsProvider(
                    context,
                    "ap-northeast-2:6d58538f-d438-48f3-bd0e-dc7455119ea3", // 자격 증명 풀 ID
                    Regions.AP_NORTHEAST_2  // 물리적인 저장 위치 서울
            );


            AmazonS3 s3 = new AmazonS3Client(credentialsProvider);
            transferUtility = new TransferUtility(s3, context);
        }
        return transferUtility;
    }
}
